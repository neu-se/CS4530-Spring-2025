// the Stories example, from https://mongoosejs.com/docs/populate.html

import mongoose from 'mongoose';
import { Schema } from 'mongoose';

async function connect() {
    const uri = "mongodb://127.0.0.1:27017/tutorial";  // dont say 'localhost', say '
    await mongoose.connect(uri);
    const db = mongoose.connection;
    db.on('error', console.error.bind(console, 'connection error:'));
    db.once('open', function() {
        console.log("Connected to database");
    });
}

// DEFINITIONS

// each person has a set of stories.  Stories are represented by their ObjectIds.

const personSchema = new Schema({
    name: String,
    age: Number,
    stories: [{ type: Schema.Types.ObjectId, ref: 'Story' }]
});

// each story has an author and some fans

const storySchema = new Schema({
    author: { type: Schema.Types.ObjectId, ref: 'Person' },
    title: String,
    fans: [{ type: Schema.Types.ObjectId, ref: 'Person' }]
});

const Story = mongoose.model('Story', storySchema);
const Person = mongoose.model('Person', personSchema);

// now we'll do something with these models

async function main() {
    await connect()
    // clear out the database
    Story.deleteMany();
    Person.deleteMany();

const ian_fleming = new Person({
    _id: new mongoose.Types.ObjectId(),
    name: 'Ian Fleming',
    age: 50
});

await ian_fleming.save()

const casinoRoyale = new Story({
    title: 'Casino Royale',
    author: ian_fleming._id // assign the _id from the person
});

await casinoRoyale.save()

const SICP = new Story({
    title: 'Structure and Interpretation of Computer Programs',
    author: ian_fleming._id
});

// this really shouldn't typecheck, because the author property is a Person, not an ObjectId.
// but it does: something is coercing the person to an object id.

const casinoRoyale2 = new Story({
    title: 'Casino Royale2',
    author: ian_fleming
});

await casinoRoyale2.save()

const theSpyWhoLovedMe = new Story({
    title: 'The Spy Who Loved Me',
    author: ian_fleming._id
});

await theSpyWhoLovedMe.save()

// the typechecker correctly rejects this, because the fan property is an ObjectId[], not a Person.
// casinoRoyale.fans.push(ian_fleming);

// this is accepted
casinoRoyale.fans.push(ian_fleming._id);

// this is accepted also, because the typechecker doesn't seem to work across refs.
// casinoRoyale.fans.push(casinoRoyale._id);

async function printStories() {
    const stories = await Story.find({author: ian_fleming._id})
    console.log(stories)
    console.log(`${ian_fleming.name} wrote ${stories.length} stories`)


}


const story1 = await Story.
  findOne({ title: 'Casino Royale' }).
  populate('author').
  exec();
// prints "The author is Ian Fleming"
console.log('The author is %s', story1?.author?.name);



// does casinoRoyale2 show up?  It shouldn't, because it's not a valid story.
// but it does! So the typechecking is not working.
// await printStories()



// console.log('populating CR fans')

// const CRfans = await Story.find({title: 'Casino Royale'}).populate('fans')

// console.log(CRfans)

const matthias = new Person({
    name: 'Matthias Felleisen',
    age: 50
});

await matthias.save()

const danFriedman = new Person({
    name: 'Dan Friedman',
    age: 80
});

await danFriedman.save()

theSpyWhoLovedMe.fans.push(matthias._id)
theSpyWhoLovedMe.fans.push(danFriedman._id)

// sync....
await SICP.save()

console.log('the Spy Who Loved Me', theSpyWhoLovedMe)

const fans = await theSpyWhoLovedMe.fans // this is an array of ObjectIds 
console.log(`IDs of the fans of The Spy Who Loved Me: ${fans}`)

// this is a destructive update of the document
const fans2 = await theSpyWhoLovedMe.populate('fans');
console.log(`fans of The Spy Who Loved Me:`);

    console.log(fans2)

    console.log('the Spy Who Loved Me, after population', theSpyWhoLovedMe)






console.log("done, hit Ctrl-C to exit")


}

main()
