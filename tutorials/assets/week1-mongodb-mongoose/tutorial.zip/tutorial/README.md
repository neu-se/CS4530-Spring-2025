# MongoDB and Mongoose Tutorial

This tutorial provides basic introduction to MondoDB, using **Mongoose** and **TypeScript**. It
covers examples of common MongoDB queries, like `find` and `populate`. You'll learn how to:

- Use Mongoose to define schemas and models
- Query documents from MongoDB
- Update and retrieve documents based on various conditions
- Populate references between collections

The database schema used for the examples is shown in the diagram below:

![Tutorial Database Schema](./tutorial-schema.png)

## Available Scripts

There are two main scripts available to run the tutorial examples:

### 1. **`quick-tutorial`**

Run the tutorial examples without pauses. This script executes all the queries and outputs the
results in a sequence.

**Command:**

`npm run quick-tutorial`

### 2. **`step-by-step`**

Run the tutorial examples with a pause after each query. This script gives you time to review the
results before proceeding to the next query. Use this option for a more interactive experience.
Enter `Ctrl-C` twice to exit at any time.

**Command:**

`npm run step-by-step`

## Setup Instructions

1. Clone or download the repository.
2. Install dependencies:

   `npm install`

3. Run the tutorial with either script:

   - `npm run quick-tutorial` for a full, uninterrupted run.
   - `npm run step-by-step` for a paused, interactive run.
