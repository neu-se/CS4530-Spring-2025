import Mongoose, { Schema } from 'mongoose';
import { ObjectId } from 'mongodb';

// before you run this, make sure you have a mongodb server running on localhost:27017
// then make sure you have a database called 'tutorial' on that server
// and then make sure you have collections called 'dogs' and 'cats' in that database
// the easiest way to do this is to use MongoDB Compass, which is a GUI for MongoDB.


export default async function main() {
    const uri = "mongodb://127.0.0.1:27017/tutorial";  // dont say 'localhost', say '
    await Mongoose.connect(uri);
    const db = Mongoose.connection;
    db.on('error', console.error.bind(console, 'connection error:'));
    db.once('open', function() {
        console.log("Connected to database");
    });
    everythingelse()
    console.log('done with main function');
}

async function everythingelse() {

    // create some Schemas
    const dogSchema = new Schema({ 
        name: String, age: Number, breed: String, 
        owner: { type: ObjectId, ref: 'Person' }  // a link to another document
     })
    const PersonSchema = new Schema({ name: String, age: Number, occupation: String })
   
    // and their matching interfaces

    interface Dog { name: String, age: Number, breed: String, owner: ObjectId }

    // create some models
    const Dog = Mongoose.model('Dog', dogSchema) 
    const Person = Mongoose.model('Person', PersonSchema)     
    // const Cat = Mongoose.model('Cat', catSchema)

    // how many dogs are there?
    const dogCount = await Dog.countDocuments();
    console.log('dog count:', dogCount);
    // remove them all
    await Dog.deleteMany();
    console.log('dogs removed');
    console.log('new dog count:', await Dog.countDocuments());


    // DogModel would be a bad name because then you'd be writing
    // new DogModel(), but you're not creating a new model, you're creating a new document
    
    // create some documents
    const dog1 = new Dog({ name: 'Rex', age: 5, breed: 'Golden Retriever' });
    const dog2 = new Dog({ name: 'Buddy', age: 3, breed: 'Labrador' });
    const dog3 = new Dog({ name: 'Max', age: 4, breed: 'Labrador' });
    const dog4 = new Dog({ name: 'Buddy', age: 17, breed: 'Labrador' });

    // const cat1 = new Cat({ name: 'Whiskers', color: 'White' });    
    // const cat2 = new Cat({ name: 'Tom', color: 'Black' });

    // save the documents, and wait til that's done
    await Promise.all([dog1.save(), dog2.save(), dog3.save(), dog4.save()]);
    console.log('Dogs and cats saved to database');

    // query builders

    async function findAllDogsQuery() {
        return Dog.find();
    }

    // a query to find all dogs of a certain breed
    async function findDogsByBreed(breed: string) {
        return Dog.find({ breed: breed });
    }

    // a query to find the ages of all dogs of a certain breed
    async function findAgesOfDogsByBreed(breed: string) {
        const dogs = await Dog.find({ breed: breed }).exec();
        return dogs.map(dog => {dog.name, dog.age})    
    }

    // execute the queries

    console.log('executing queries');

    const dogs = await Dog.find();
    console.log('Dog.find:', dogs);
    
    const findAllDogsQueryResults = await findAllDogsQuery();
    console.log('findAllDogsQuery:', findAllDogsQueryResults);

    // here on the left, Dog is in the position of a type, so it refers to the 
    // interface defined above, not the model.

    const labradors = await Dog.find({ breed: 'Labrador' });    
    console.log('Dog.find({ breed: Labrador}', labradors);

    const data = await Dog.find({ breed: 'Labrador' }).select('name age');
    console.log('Dog.find({ breed: Labrador }).select(name age):', data);

    const data2 = await Dog.find({ breed: 'Labrador' }).select('name age').exec();
    console.log('Dog.find({ breed: Labrador }).select(name age).exec():', data2);

    // this one doesn't work
    const data3 = await findAgesOfDogsByBreed('Labrador');
    console.log('findAgesOfDogsByBreed(Labrador):', data3);

    const buddy = await Dog.findOne({ name: 'Buddy' });
    console.log('Dog.findOne({ name: Buddy }):', buddy);

    const buddy2 = await Dog.findOne({ name: 'Buddy' });
    console.log('buddy2 = Dog.findOne({ name: Buddy }):', buddy2);

    console.log('done executing queries, hit ctrl-c to exit');
}     
 
// run the main function
main();
