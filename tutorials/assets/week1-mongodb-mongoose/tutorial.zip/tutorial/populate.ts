// the Stories example, from https://mongoosejs.com/docs/populate.html

import mongoose from 'mongoose';
import { Schema } from 'mongoose';

// in this database, we have persons and books.

const personSchema = new Schema({
    name: String,
    age: Number,
});

const Person = mongoose.model('Person', personSchema);

const bookSchema = new Schema({
    title: String,
    authors: [{ type: Schema.Types.ObjectId, ref: 'Person' }],
    readers: [{ type: Schema.Types.ObjectId, ref: 'Person' }]
});

const Book = mongoose.model('Book', bookSchema);

// GOAL: WRITE THIS FUNCTION:

// // given the title of a book, return the list of ages of the authors.
// async function getAges(title: string) {
//     const book = await Book.findOne({title: title}).populate('authors').exec();
//     return book?.authors.map(author => author?.age) 
// }

async function connect() {
    const uri = "mongodb://127.0.0.1:27017/tutorial";  // dont say 'localhost', say '
    await mongoose.connect(uri);
    const db = mongoose.connection;
    db.on('error', console.error.bind(console, 'connection error:'));
    db.once('open', function () {
        console.log("Connected to database");
    });
}

async function main() {
    await connect()
    // clear out the database
    await Book.deleteMany();
    await Person.deleteMany();

    const matthias = new Person({
        name: 'Matthias Felleisen',
        age: 60
    });    

    const robbieFindler = new Person({
        name: 'Robbie Findler',
        age: 45
    });   

    const danFriedman = new Person({
        name: 'Dan Friedman',
        age: 80
    });
    
    const mitchWand = new Person({
        name: 'Mitch Wand',
        age: 70
    });

    const people = [matthias, robbieFindler, danFriedman, mitchWand]

    await Promise.all(people.map(person => person.save()))

    const HTDP = new Book({
        title: 'How to Design Programs',
        authors: [matthias._id, robbieFindler._id]
    });

    await HTDP.save()

    // populating a document means filling in the fields that are ObjectIds with the actual objects.
    const htdpDocument = await Book.findOne({title: 'How to Design Programs'})
        .populate({path: 'authors', model: Person}).exec();

    // populate destructively updates the document
    console.log('htdpDocument after population', htdpDocument)

    console.log('htdpDocument.authors', htdpDocument?.authors)

    const authors = htdpDocument?.authors

    // mwah! This doesn't typecheck, because TS thinks that htdpDocument.authors is an array of ObjectIds.
    const ages = authors?.map(author => author?.age)


    
    console.log("done, hit Ctrl-C to exit")
}

main()
