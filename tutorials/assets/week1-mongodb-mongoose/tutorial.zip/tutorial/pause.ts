import readline from 'readline';

// Create the pause function with a new readline instance each time
function pause() {
  return new Promise<void>(resolve => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });

    rl.question('Press Enter to continue...\n', () => {
      rl.close(); // Close the readline instance after receiving input
      resolve(); // Resolve the promise once the user presses Enter
    });
  });
}

export default pause;
