import mongoose from 'mongoose';

/**
 * Establishes a connection to the MongoDB database.
 *
 * The function performs the following steps:
 * 1. Connects to the MongoDB instance at the specified URI.
 * 2. Sets up event listeners to handle connection errors and successful connection events.
 * 3. Logs a success message when the connection is established.
 *
 * @throws {Error} If the connection to the database fails.
 */
async function connectDatabase() {
  // MongoDB connection URI for the tutorial database
  const uri = 'mongodb://127.0.0.1:27017/tutorial';

  // Attempt to connect to the MongoDB database
  await mongoose
    .connect(uri, { serverSelectionTimeoutMS: 15000 })
    .then(() => console.log('Connected to database!'))
    .catch(err => {
      if (err.message.includes('ECONNREFUSED')) {
        throw new Error(
          `MongoDB connection error: Connection refused. Please run the mongo service before starting.\n\n${err}`,
        );
      } else {
        throw new Error(`MongoDB connection error: ${err}`);
      }
    });
}

export default connectDatabase;
