import KittyModel from '../models/kitty.model';
import VetModel from '../models/vet.model';
import { GREEN, RESET, YELLOW } from '../types';
import pause from '../pause';

/**
 * Populate the `vet` field in Kitty documents.
 */
async function populateVetInKitties() {
  console.log(`${YELLOW}Query 1: Populate the \`vet\` field in Kitty documents.${RESET}`);
  console.log('Code to run:');
  console.log("const kittiesWithVet = await KittyModel.find().populate('vet');\n");
  const kittiesWithVet = await KittyModel.find().populate('vet');
  console.log(
    'Result: Kitties with their vets populated:',
    JSON.stringify(kittiesWithVet, null, 2),
  );
  console.log(`${GREEN}--- End of Query 1 ---${RESET}\n`);
}

/**
 * Populate both `vet` and `clinic` fields in Kitty and Vet documents.
 */
async function populateVetAndClinicInKitties() {
  console.log(
    `${YELLOW}Query 2: Populate both \`vet\` and \`clinic\` fields in Kitty and Vet documents.${RESET}`,
  );
  console.log('Code to run:');
  console.log(
    "const kittiesWithVetAndClinic = await KittyModel.find().populate({ path: 'vet', populate: { path: 'clinic' } });\n",
  );
  const kittiesWithVetAndClinic = await KittyModel.find().populate({
    path: 'vet',
    populate: { path: 'clinic' },
  });
  console.log(
    'Result: Kitties with their vets and clinics populated:',
    JSON.stringify(kittiesWithVetAndClinic, null, 2),
  );
  console.log(`${GREEN}--- End of Query 2 ---${RESET}\n`);
}

/**
 * Populate the `clinic` field in Vet documents.
 */
async function populateClinicInVets() {
  console.log(`${YELLOW}Query 3: Populate the \`clinic\` field in Vet documents.${RESET}`);
  console.log('Code to run:');
  console.log("const vetsWithClinics = await VetModel.find().populate('clinic');\n");
  const vetsWithClinics = await VetModel.find().populate('clinic');
  console.log(
    'Result: Vets with their clinics populated:',
    JSON.stringify(vetsWithClinics, null, 2),
  );
  console.log(`${GREEN}--- End of Query 3 ---${RESET}\n`);
}

/**
 * Populate the `clinic` field in a specific Vet, selecting only `name` and `city`.
 */
async function populateClinicInSpecificVet() {
  console.log(
    `${YELLOW}Query 4: Populate the \`clinic\` field in a specific Vet, selecting only \`name\` and \`city\` fields.${RESET}`,
  );
  console.log('Code to run:');
  console.log(
    `const vetWithClinic = await VetModel.findOne({ name: 'Dr. Emily Johnson' }).populate('clinic', 'name city');\n`,
  );
  const vetWithClinic = await VetModel.findOne({ name: 'Dr. Emily Johnson' }).populate(
    'clinic',
    'name city',
  );
  console.log('Result: Vet with their clinic details:', JSON.stringify(vetWithClinic, null, 2));
  console.log(`${GREEN}--- End of Query 4 ---${RESET}\n`);
}

/**
 * Retrieve all orange kitties and populate their `vet` field.
 */
async function populateVetInOrangeKitties() {
  console.log(
    `${YELLOW}Query 5: Retrieve all orange kitties and populate their \`vet\` field.${RESET}`,
  );
  console.log('Code to run:');
  console.log(
    "const orangeKittiesWithVets = await KittyModel.find({ color: 'Orange' }).populate('vet');\n",
  );
  const orangeKittiesWithVets = await KittyModel.find({ color: 'Orange' }).populate('vet');
  console.log(
    'Result: Orange kitties with their vets populated:',
    JSON.stringify(orangeKittiesWithVets, null, 2),
  );
  console.log(`${GREEN}--- End of Query 5 ---${RESET}\n`);
}

/**
 * Populate the `vet` field in Kitty documents where the vet's age is greater than 40, selecting only `name`.
 */
async function populateVetOver40InKitties() {
  console.log(
    `${YELLOW}Query 6: Populate the \`vet\` field in Kitty documents where the vet's age is greater than 40, selecting only \`name\` field.${RESET}`,
  );
  console.log('Code to run:');
  console.log(
    `const kittiesWithVetOver40 = await KittyModel.find().populate({
    path: 'vet',
    match: { age: { $gt: 40 } },
    select: 'name',
  });\n`,
  );
  const kittiesWithVetOver40 = await KittyModel.find().populate({
    path: 'vet',
    match: { age: { $gt: 40 } },
    select: 'name',
  });
  console.log(
    'Result: Kitties with vets older than 40:',
    JSON.stringify(kittiesWithVetOver40, null, 2),
  );
  console.log(`${GREEN}--- End of Query 6 ---${RESET}\n`);
}

/**
 * Retrieve Tabby kitties and populate their `vet` field with only the `name` field selected.
 */
async function populateVetInTabbyKitties() {
  console.log(
    `${YELLOW}Query 7: Retrieve Tabby kitties and populate their \`vet\` field with only the \`name\` field selected.${RESET}`,
  );
  console.log('Code to run:');
  console.log(
    "const tabbyKitties = await KittyModel.find({ color: 'Tabby' }).populate('vet', 'name');\n",
  );
  const tabbyKitties = await KittyModel.find({ color: 'Tabby' }).populate('vet', 'name');
  console.log(
    'Result: Tabby kitties and their vets (name only):',
    JSON.stringify(tabbyKitties, null, 2),
  );
  console.log(`${GREEN}--- End of Query 7 ---${RESET}\n`);
}

/**
 * Populate both `vet` and `clinic` fields in Kitty documents, filtering for Boston clinics.
 */
async function populateVetAndBostonClinicInKitties() {
  console.log(
    `${YELLOW}Query 8: Populate both \`vet\` and \`clinic\` fields in Kitty documents, only populating for Boston clinics.${RESET}`,
  );
  console.log('Code to run:');
  console.log(`const kittiesWithBostonClinic = await KittyModel.find().populate({
    path: 'vet',
    populate: {
      path: 'clinic',
      match: { city: 'Boston' },
      select: 'name',
    },
  });\n`);
  const kittiesWithBostonClinic = await KittyModel.find().populate({
    path: 'vet',
    populate: {
      path: 'clinic',
      match: { city: 'Boston' },
      select: 'name',
    },
  });
  console.log(
    'Result: Kitties with vets and Boston clinics:',
    JSON.stringify(kittiesWithBostonClinic, null, 2),
  );
  console.log(`${GREEN}--- End of Query 8 ---${RESET}\n`);
}

async function runPopulateQueryExamples(pauseAfterEachQuery: boolean) {
  console.log('Running all examples for POPULATE queries...');

  // Example 1: Populate vet field in Kitties
  await populateVetInKitties();
  if (pauseAfterEachQuery) await pause();

  // Example 2: Populate vet and clinic fields in Kitties
  await populateVetAndClinicInKitties();
  if (pauseAfterEachQuery) await pause();

  // Example 3: Populate clinic field in Vets
  await populateClinicInVets();
  if (pauseAfterEachQuery) await pause();

  // Example 4: Populate clinic in specific vet
  await populateClinicInSpecificVet();
  if (pauseAfterEachQuery) await pause();

  // Example 5: Populate vet in orange kitties
  await populateVetInOrangeKitties();
  if (pauseAfterEachQuery) await pause();

  // Example 6: Populate vet over 40 in kitties
  await populateVetOver40InKitties();
  if (pauseAfterEachQuery) await pause();

  // Example 7: Populate vet in tabby kitties
  await populateVetInTabbyKitties();
  if (pauseAfterEachQuery) await pause();

  // Example 8: Populate vet and clinic in Boston
  await populateVetAndBostonClinicInKitties();
  if (pauseAfterEachQuery) await pause();

  console.log('All POPULATE queries completed.\n');
}

export default runPopulateQueryExamples;
