import KittyModel from '../models/kitty.model';
import VetModel from '../models/vet.model';
import ClinicModel from '../models/clinic.model';

/**
 * Populates the MongoDB database with sample data.
 *
 * This function performs the following steps:
 * 1. Clears any existing data in the `Kitty`, `Vet`, and `Clinic` collections.
 * 2. Creates three sample `Clinic` documents.
 * 3. Creates two sample `Vet` documents, each associated with a clinic.
 * 4. Creates four sample `Kitty` documents, each associated with a vet.
 *
 * @throws {Error} Logs any errors encountered during the data creation process.
 */
async function createDatabase() {
  try {
    // Clear any existing data in the Kitty, Vet, and Clinic collections
    await KittyModel.deleteMany({});
    await VetModel.deleteMany({});
    await ClinicModel.deleteMany({});

    // Create sample Clinics
    const clinic1 = new ClinicModel({
      name: 'Happy Tails Veterinary Clinic',
      city: 'Boston',
      phone: '123-456-7890', // Optional phone number
    });
    const clinic2 = new ClinicModel({
      name: 'Purrfect Car Animal Hospital',
      city: 'Cambridge',
      phone: '987-654-3210', // Optional phone number
    });
    const clinic3 = new ClinicModel({
      name: 'Whisker Wellness Clinic',
      city: 'Somerville', // No phone number provided
    });

    // Save the clinic data to the database
    await clinic1.save();
    await clinic2.save();
    await clinic3.save();

    // Create sample Vets associated with each clinic
    const vet1 = new VetModel({
      name: 'Dr. Emily Johnson',
      age: 35,
      clinic: clinic1._id, // Reference clinic1
    });
    const vet2 = new VetModel({
      name: 'Dr. Robert Smith',
      age: 42,
      clinic: clinic2._id, // Reference clinic2
    });

    // Save the vet data to the database
    await vet1.save();
    await vet2.save();

    // Create sample Kitties associated with each vet
    const kitty1 = new KittyModel({
      name: 'Tiger',
      color: 'Tabby',
      favoriteToy: 'Laser Pointer',
      vet: vet1._id, // Reference vet1
    });
    const kitty2 = new KittyModel({
      name: 'Luna',
      color: 'Black',
      // No favorite toy provided, defaults to None
      vet: vet1._id, // Reference vet1
    });
    const kitty3 = new KittyModel({
      name: 'Cheddar',
      color: 'Orange',
      favoriteToy: 'Cardboard Box',
      vet: vet2._id, // Reference vet2
    });
    const kitty4 = new KittyModel({
      name: 'Bean',
      color: 'Orange',
      favoriteToy: 'Ball of Yarn',
      vet: vet2._id, // Reference vet2
    });

    // Save the kitty data to the database
    await kitty1.save();
    await kitty2.save();
    await kitty3.save();
    await kitty4.save();

    // Log a success message when the data is created
    console.log(
      'Sample data created successfully! View all inserted documents using MongoDB Compass.',
    );
  } catch (error) {
    // Log an error message if any part of the data creation process fails
    console.error('Error creating sample data:', error);
  }
}

export default createDatabase;
