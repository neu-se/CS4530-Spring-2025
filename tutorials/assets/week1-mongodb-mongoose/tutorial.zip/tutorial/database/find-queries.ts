import { SortOrder } from 'mongoose';
import KittyModel from '../models/kitty.model';
import VetModel from '../models/vet.model';
import ClinicModel from '../models/clinic.model';
import { GREEN, RESET, YELLOW } from '../types';
import pause from '../pause';

/**
 * Retrieve all kitties in the database.
 */
async function getAllKitties() {
  console.log(`${YELLOW}Query 1: Retrieve all kitties in the database.${RESET}`);
  console.log('Code to run:');
  console.log('const allKitties = await KittyModel.find();\n');
  const allKitties = await KittyModel.find();
  console.log('Result: All Kitties:', JSON.stringify(allKitties, null, 2));
  console.log(`${GREEN}--- End of Query 1 ---${RESET}\n`);
}

/**
 * Retrieve kitties with a specific color.
 */
async function getKittiesByColor(color: string) {
  console.log(`${YELLOW}Query 2: Retrieve kitties with a specific color.${RESET}`);
  console.log('Code to run:');
  console.log(`const kitties = await KittyModel.find({ color: '${color}' });\n`);
  const kitties = await KittyModel.find({ color });
  console.log(`Result: Kitties with color "${color}":`, JSON.stringify(kitties, null, 2));
  console.log(`${GREEN}--- End of Query 2 ---${RESET}\n`);
}

/**
 * Retrieve kitties with multiple colors using `$in`.
 */
async function getKittiesByColors(colorOptions: string[]) {
  console.log(`${YELLOW}Query 3: Retrieve kitties with multiple colors using \`$in\`.${RESET}`);
  console.log('Code to run:');
  console.log(
    `const kitties = await KittyModel.find({ color: { $in: ${JSON.stringify(colorOptions)} } });\n`,
  );
  const kitties = await KittyModel.find({ color: { $in: colorOptions } });
  console.log(
    `Result: Kitties with color in "${colorOptions.join(', ')}":`,
    JSON.stringify(kitties, null, 2),
  );
  console.log(`${GREEN}--- End of Query 3 ---${RESET}\n`);
}

/**
 * Retrieve vets older than a certain age.
 */
async function getVetsOlderThanAge(minAge: number) {
  console.log(`${YELLOW}Query 4: Retrieve vets older than a certain age.${RESET}`);
  console.log('Code to run:');
  console.log(`const vets = await VetModel.find({ age: { $gt: ${minAge} } });\n`);
  const vets = await VetModel.find({ age: { $gt: minAge } });
  console.log(`Result: Vets older than ${minAge}:`, JSON.stringify(vets, null, 2));
  console.log(`${GREEN}--- End of Query 4 ---${RESET}\n`);
}

/**
 * Retrieve kitties cared for by a specific vet.
 */
async function getKittiesForVet(vetName: string) {
  console.log(`${YELLOW}Query 5: Retrieve kitties cared for by a specific vet.${RESET}`);
  console.log('Code to run:');
  console.log(`const vet = await VetModel.findOne({ name: '${vetName}' });\n`);
  const vet = await VetModel.findOne({ name: vetName });
  if (vet) {
    console.log('Code to run:');
    console.log(`const kittiesForVet = await KittyModel.find({ vet: '${vet._id}' });\n`);
    const kittiesForVet = await KittyModel.find({ vet: vet._id });
    console.log(`Result: Kitties cared for by ${vetName}:`, JSON.stringify(kittiesForVet, null, 2));
  } else {
    console.log(`No vet found with name: ${vetName}`);
  }
  console.log(`${GREEN}--- End of Query 5 ---${RESET}\n`);
}

/**
 * Retrieve vets sorted by age in a specific order.
 */
async function getVetsSortedByAge(order: SortOrder) {
  console.log(`${YELLOW}Query 6: Retrieve vets sorted by age in a specific order.${RESET}`);
  console.log('Code to run:');
  console.log(
    `const allVetsSortByAge = await VetModel.find().sort({ age: '${order}' }).select({ name: 1 });\n`,
  );
  const allVetsSortByAge = await VetModel.find().sort({ age: order }).select({ name: 1 });
  console.log(`Result: Vets in ${order} order of age:`, JSON.stringify(allVetsSortByAge, null, 2));
  console.log(`${GREEN}--- End of Query 6 ---${RESET}\n`);
}

/**
 * Update the phone number of a clinic and return the updated clinic.
 */
async function updateClinicPhone(newPhone: string) {
  console.log(`${YELLOW}Query 7: Update the phone number of a clinic.${RESET}`);
  console.log('Code to run:');
  console.log(`const updatedClinic = await ClinicModel.findOneAndUpdate(
    { name: 'Whisker Wellness Clinic' },
    { $set: { phone: '${newPhone}' } },
    { new: true }
  );\n`);
  const updatedClinic = await ClinicModel.findOneAndUpdate(
    { name: 'Whisker Wellness Clinic' },
    { $set: { phone: newPhone } },
    { new: true },
  );
  console.log('Result: Updated clinic phone number:', JSON.stringify(updatedClinic, null, 2));
  console.log(`${GREEN}--- End of Query 7 ---${RESET}\n`);
}

/**
 * Update Luna's favorite toy.
 */
async function updateKittyFavoriteToy(newToy: string) {
  console.log(`${YELLOW}Query 8: Update the favorite toy of Luna.${RESET}`);
  console.log('Code to run:');
  console.log(`const updatedKitty = await KittyModel.findOneAndUpdate(
    { name: 'Luna' },
    { $set: { favoriteToy: '${newToy}' } },
    { new: true }
  );\n`);
  const updatedKitty = await KittyModel.findOneAndUpdate(
    { name: 'Luna' },
    { $set: { favoriteToy: newToy } },
    { new: true },
  );
  console.log('Result: Updated Luna document:', JSON.stringify(updatedKitty, null, 2));
  console.log(`${GREEN}--- End of Query 8 ---${RESET}\n`);
}

/**
 * Run all examples, with an option to pause after each query.
 */
async function runFindQueryExamples(pauseAfterEachQuery: boolean) {
  console.log('\nRunning all examples for FIND queries...\n');

  // Example 1: Retrieve all kitties
  await getAllKitties();
  if (pauseAfterEachQuery) await pause();

  // Example 2: Retrieve kitties by a specific color
  await getKittiesByColor('Orange');
  if (pauseAfterEachQuery) await pause();

  // Example 3: Retrieve kitties by multiple colors
  await getKittiesByColors(['Black', 'Tabby']);
  if (pauseAfterEachQuery) await pause();

  // Example 4: Retrieve vets older than a certain age
  await getVetsOlderThanAge(37);
  if (pauseAfterEachQuery) await pause();

  // Example 5: Retrieve kitties cared for by a specific vet
  await getKittiesForVet('Dr. Emily Johnson');
  if (pauseAfterEachQuery) await pause();

  // Example 6: Retrieve vets sorted by age
  await getVetsSortedByAge('descending');
  if (pauseAfterEachQuery) await pause();

  // Example 7: Update clinic phone number
  await updateClinicPhone('123-123-1234');
  if (pauseAfterEachQuery) await pause();

  // Example 8: Update Luna's favorite toy
  await updateKittyFavoriteToy('Fuzzy Sock');
  if (pauseAfterEachQuery) await pause();

  console.log('\nAll FIND queries completed.\n');
}

export default runFindQueryExamples;
