// the Stories example, from https://mongoosejs.com/docs/populate.html

import mongoose from 'mongoose';
import { Schema } from 'mongoose';

async function connect() {
    const uri = "mongodb://127.0.0.1:27017/tutorial";  // dont say 'localhost', say '
    await mongoose.connect(uri);
    const db = mongoose.connection;
    db.on('error', console.error.bind(console, 'connection error:'));
    db.once('open', function () {
        console.log("Connected to database");
    });
}

// DEFINITIONS

// in this database, we have persons and books.

const personSchema = new Schema({
    name: String,
    age: Number,
});

const Person = mongoose.model('Person', personSchema);

const bookSchema = new Schema({
    title: String,
    authors: [{ type: Schema.Types.ObjectId, ref: 'Person' }],
    readers: [{ type: Schema.Types.ObjectId, ref: 'Person' }]
});

const Book = mongoose.model('Book', bookSchema);

interface PopulatedBook extends Document {
    title: string;
    authors: (typeof Person)[]
}



// now we'll do something with these models

async function main() {
    await connect()
    // clear out the database
    await Book.deleteMany();
    await Person.deleteMany();

    const ian_fleming = new Person({
        // not necessary to write this line; the _id is automatically generated.
        _id: new mongoose.Types.ObjectId(),
        name: 'Ian Fleming',
        age: 120
    });

    await ian_fleming.save()

    const matthias = new Person({
        name: 'Matthias Felleisen',
        age: 60
    });

    await matthias.save()

    const robbieFindler = new Person({
        name: 'Robbie Findler',
        age: 45
    });

    await robbieFindler.save()

    const danFriedman = new Person({
        name: 'Dan Friedman',
        age: 80
    });

    await danFriedman.save() 
    
    const mitchWand = new Person({
        name: 'Mitch Wand',
        age: 70
    });

    await mitchWand.save()

    // if you had a lot of people, you could do this with a PromiseAll.

    const casinoRoyale = new Book({
        title: 'Casino Royale',
        authors: [ian_fleming._id] // assign the _id from the person
    });

    await casinoRoyale.save()

    const HTDP = new Book({
        title: 'How to Design Programs',
        authors: [matthias._id, robbieFindler._id]
    });

    await HTDP.save()


    // what does the readers field look like?
    // .find() returns a query, so we need to use findOne() to get the actual object.
    // And we need to use await to get the actual object.
    console.log('HTDP', await Book.findOne({title: 'How to Design Programs'}))

    // does this work?  It shouldn't because matthias is not an ObjectId.
    const HTDPBogus1 = new Book({        
        title: 'How to Design Programs Bogus1',
        authors: [matthias, robbieFindler]
    });

    await HTDPBogus1.save()
    console.log('HTDPBogus1', await Book.findOne({title: 'How to Design Programs Bogus1'}))

    // adding a reader (doesn't save automatically)
    HTDP.readers.push(danFriedman._id)
    HTDP.readers.push(mitchWand._id)
    // save the updates to the database
    const HTDPupdated = await HTDP.save()
    console.log('HTDP with readers', await Book.findOne({title: 'How to Design Programs'}))

    // HTDP.save() returns the updated document, so we can do this:
    // console.log('HTDPupdated', HTDPupdated)

    // this doesn't typecheck.
    // await HTDP.readers.push(matthias._id).save()

    // // this actually does typecheck, but it shouldn't work because casinoRoyale is not a Person.
    // // <:shrug:>
    // HTDP.readers.push(casinoRoyale._id)
    // await HTDP.save()

    // console.log('HTDP with readers, after adding casinoRoyale', await Book.findOne({title: 'How to Design Programs'}))

    // ages of the authors of HTDP
    // this doesn't work: htdp.authors is an array of ObjectIds, not an array of Persons.
    // async function getAges_firstTry() {
    //     const htdp = await Book.findOne({title: 'How to Design Programs'})       
    //     return htdp?.authors.map(author => author.age)
    // }      

    // populating a document means filling in the fields that are ObjectIds with the actual objects.
    const htdpDocument = await Book.findOne({title: 'How to Design Programs'})
        .populate({path: 'authors', model: Person}).exec();

    // populate destructively updates the document
    console.log('htdpDocument after population', htdpDocument)

    console.log('htdpDocument.authors', htdpDocument?.authors)

    interface PopulatedBook extends Document {
        title: string;
        authors: (typeof Person)[]
        }

    // const authors2 = (htdpDocument? as PopulatedBook).authors

    // mwah! This doesn't typecheck, because TS thinks that htdpDocument.authors is an array of ObjectIds.
   //  const ages2 = authors?.map(author => author?.age)

    // solution: use as 'as' to tell TS the actual type

    // interface PopulatedBook extends Book {
    //     title: string;
    //     authors: typeof Person[]
    // }

    async function getAges(title: string): Promise<number[] | undefined> {
        const book = await Book.findOne({ title: title })
            .populate('authors')
            .exec() as PopulatedBook;  // Cast to PopulatedBook    
        return book?.authors.map(author => author.age);
    }
    
    const ages = authors?.map(author => author?.age)

    // mwah! This doesn't typecheck, because TS thinks that htdpDocument.authors is an array of ObjectIds.
    // console.log('htdpDocument.authors.amp age', htdpDocument?.authors.map(author => author?.age))

    // // calling .populate() on the document doesn't change anything in the database.
    // const htdpDocument2 = await Book.findOne({ title: 'How to Design Programs' })
    // console.log('htdpDocument2', htdpDocument2)

    // console.log('htdpDocument2.authors', htdpDocument2?.authors)

    // given the title of a book, return the list of ages of the authors.
    // async function getAges(title: string) {
    //     const book = await Book.findOne({title: title}).populate('authors').exec();
    //     return book?.authors.map(author => author?.name) 
    // }

    // console.log('ages of authors of HTDP', await getAges('How to Design Programs'))

    // solution: use as 'as' to tell TS the actual type








    console.log("done, hit Ctrl-C to exit")


}

main()
