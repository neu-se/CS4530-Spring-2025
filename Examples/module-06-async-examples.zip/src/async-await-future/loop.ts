function promiseNothing(): Promise<void> {
    return new Promise((resolve, reject) => {
        // do nothing, just resolve
        resolve();
    });
}

// an infinite "tail-recursive" loop
// the tail recursion is broken by the await.
async function loop(n) {
    console.log(n);
    await promiseNothing();
    loop(n+1);
}

loop(0);