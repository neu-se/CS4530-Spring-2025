/** given a string, returns a promise that prints the string 
 * and then resolves
 * string => Promise(void) 
 * **/
import {promiseToPrint} from "./promiseToPrint";


export async function example1(n: number): Promise<number> {
  console.log(`example1(${n}) starting`);
  const p1 = promiseToPrint(`p1 is printing`);
  await p1;
  console.log(`example1(${n}) finishing`);
  // pass this to any waiting promises
  // this is NOT the value of the async function
  return n+1;  
}

async function make3SequentialPromises() {
    console.log('starting make3SequentialPromises');
    await example1(100);
    await example1(200);
    await example1(300);
    console.log('make3SequentialPromises finished');
  }

  make3SequentialPromises()