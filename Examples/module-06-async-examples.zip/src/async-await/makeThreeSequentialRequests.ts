import axios from 'axios';
import { timeIt } from '../utils/timeIt';

export async function makeRequest(requestNumber: number) {
  console.log(`starting makeRequest(${requestNumber})`);
  const response = await axios.get('https://rest-example.covey.town');
  console.log(`request ${requestNumber} returned`);
}


async function make3SequentialRequests() {
  console.log('starting make3SequentialRequests');
  await makeRequest(100);
  await makeRequest(200);
  await makeRequest(300);
  console.log('make3SequentialRequests finished');
}

async function main() {
  const time = await timeIt(make3SequentialRequests)
  console.log(`time: ${time.toFixed(2)} milliseconds`)
}

main()