/** given a string, returns a promise that prints the string 
 * and then resolves
 * string => Promise(void) 
 * **/
import {promiseToPrint} from "./promiseToPrint";


export async function example1(n: number): Promise<number> {
  console.log(`example1(${n}) starting`);
  const p1 = promiseToPrint(`p1 is printing`);
  await p1;
  console.log(`example1(${n}) finishing`);
  // pass this to any waiting promises
  // this is NOT the value of the async function
  return n+10;  
}

async function promisesPassingValues() {
    console.log('starting promisesPassingValues');
    const res1 = await example1(100);
    const res2 = await example1(res1);
    const res3 = await example1(res2);
    console.log(`res3 = ${res3}`);
    console.log('promisesPassingValues finished');
  }

  promisesPassingValues()