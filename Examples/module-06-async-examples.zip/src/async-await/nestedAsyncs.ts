/** given a string, returns a promise to print the string 
 * string => Promise(void) **/
import {promiseToPrint} from "./promiseToPrint";
// import {example1} from "./AsyncReturnsPromise";

export async function example1(n: number): Promise<void> {
  console.log(`example1(${n}) starting`);
  const p1 = promiseToPrint(`p1 is printing`);
  await p1;
  console.log(`example1(${n}) finishing`);
}

export async function example2(n: number): Promise<void> {
  console.log(`example2(${n}) starting`);
  const p1 = example1(n);
  await p1;
  console.log(`example2(${n}) finishing`);
}

function main1() {
  console.log('starting main');
  example2(10)
  console.log('main finished');
}

main1();
