// promise that prints the string
import { promiseToPrint } from "./promiseToPrint";

export async function example1(n: number): Promise<number> {
    console.log(`example1(${n}) starting`);
    await promiseToPrint(`p1 is printing`);
    console.log(`example1(${n}) finishing`);
    return n+1;  // pass this to any waiting promises
}

async function example2(n) {
    console.log(`example2(${n}) starting`);
    const res = await example1(n);
    console.log(`example2 received ${res} from example1(${n})`);
    console.log(`example2(${n}) finishing`);
}

function main2() {
  console.log('starting main');
  example2(10)
  console.log('main finished');
}

main2();