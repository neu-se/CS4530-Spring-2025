/** given a string, returns a promise that prints the string 
 * and then resolves
 * string => Promise(void) 
 * **/
import {promiseToPrint} from "./promiseToPrint";


export async function example1(n: number): Promise<number> {
  console.log(`example1(${n}) starting`);
  const p1 = promiseToPrint(`p1 is printing`);
  await p1;
  console.log(`example1(${n}) finishing`);
  // pass this to any waiting promises
  // this is NOT the value of the async function
  return n+1;  
}

function make3AsynchronousPromises() {
    console.log('starting make3AsynchronousPromises');
    example1(100);
    example1(200);
    example1(300);
    console.log('make3AsynchronousPromises finished');
  }

  make3AsynchronousPromises()
