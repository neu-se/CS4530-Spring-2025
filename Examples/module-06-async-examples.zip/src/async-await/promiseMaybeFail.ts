// promise to fail if shouldFail is true
export function promiseMaybeFail(shouldFail:boolean): Promise<void> {
    return new Promise((resolve, reject) => {
        if (shouldFail) {
            // console.log('promise failing');
            reject();
        } else {
            // console.log('promise succeeding');
        resolve();
        }
    }
    );
}