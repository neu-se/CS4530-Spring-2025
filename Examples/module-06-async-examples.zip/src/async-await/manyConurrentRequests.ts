import axios from 'axios';
import { timeIt } from '../utils/timeIt';

export async function makeRequest(requestNumber:number) {
    console.log(`starting makeRequest(${requestNumber})`);
    await axios.get('https://rest-example.covey.town');
    console.log(`request ${requestNumber} returned`);
    return requestNumber
}


// this starts the requests concurrently, 
// but waits for all of them to finish before continuing
  async function manyConcurrentRequests(requests: number[]) {
    console.log('starting manyConcurrentRequests');
    const responses = await Promise.all(requests.map(n => makeRequest(n)));
    console.log('responses:', responses);
    console.log('manyConcurrentRequests finished');
  }

async function main() {
  manyConcurrentRequests([100,200,300,400])
}

main()
