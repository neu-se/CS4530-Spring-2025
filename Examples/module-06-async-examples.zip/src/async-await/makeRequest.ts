import axios from 'axios';

export async function makeRequest(requestNumber:number) {
    console.log(`starting makeRequest(${requestNumber})`);
    const response = await axios.get('https://rest-example.covey.town');
    console.log('request:', requestNumber, '\nresponse:', response.data);
}
