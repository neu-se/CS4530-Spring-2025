/** given a string, returns a promise to print the string 
 * string => Promise(void) **/
import {promiseToPrint} from "./promiseToPrint";


export async function example1(n: number): Promise<number> {
  console.log(`example1(${n}) starting`);
  const p1 = promiseToPrint(`p1 is printing`);
  await p1;
  console.log(`example1(${n}) finishing`);
  // pass this to any waiting promises
  // this is NOT the value of the async function
  return n+1;  
}

function main1() {
  console.log('starting main');
  const val = example1(10)
  console.log ('example1(10) returned', val)
  console.log('main finished');
}

main1();
