// promise to fail if shouldFail is true
import { promiseMaybeFail } from './promiseMaybeFail'

async function script(shouldFail:boolean) {
    console.log('starting script with shouldFail = ', shouldFail);
    try {
        await promiseMaybeFail(shouldFail)
        console.log('promise succeeded');
    }
    catch (e) { console.log('promise failed, but error caught') }
    console.log('script finished successfully');
}

async function main1() {
await script(false);
console.log('\n')    
await script(true)
}

main1()
