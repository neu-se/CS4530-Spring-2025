import axios from 'axios';

export async function makeRequest(requestNumber:number) {
    console.log(`starting makeRequest(${requestNumber})`);
    const response = await axios.get('https://rest-example.covey.town');
    console.log(`request:${requestNumber} returned`);
}


  function make3ConcurrentRequests() {
    console.log('starting make3ConcurrentRequests');
    makeRequest(100);
    makeRequest(200);
    makeRequest(300);
    console.log('make3ConcurrentRequests finished');
  }

  async function make3SerialRequests() {
    console.log('starting make3SerialRequests');
    await makeRequest(100);
    await makeRequest(200);
    await makeRequest(300);
    console.log('make3SerialRequests finished');
  }

  // this starts the requests concurrently, 
  // but waits for all of them to finish before continuing
  async function correctPatternExample() {
    console.log('starting correctPatternExample');
    await Promise.all([100,200,300].map(n => makeRequest(n)));
    console.log('correctPatternExample finished');
  }

//  make3SerialRequests()
make3ConcurrentRequests()
//  correctPatternExample()

