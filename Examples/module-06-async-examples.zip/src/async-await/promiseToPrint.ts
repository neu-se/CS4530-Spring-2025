// promise that prints the string and returns void
export function promiseToPrint(str: string): Promise<void> {
    return new Promise((resolve, reject) => {
        console.log(str);
        resolve();
    });
}

// promise that prints the string and returns the number
export function promiseToPrint2(n:number, str: string): Promise<number> {
    return new Promise((resolve, reject) => {
        console.log(str);
        resolve(n);
    });
}
