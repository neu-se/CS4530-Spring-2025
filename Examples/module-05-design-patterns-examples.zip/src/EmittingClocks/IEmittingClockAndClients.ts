import { EventEmitter } from "events"
import TypedEmitter from "typed-emitter"

type ClockEvents = {
    reset: () => void
    tick: (time: number) => void, // carries the current time
}

class SampleEmitterServer {
    private emitter = new EventEmitter as TypedEmitter<ClockEvents>
    public getEmitter():TypedEmitter<ClockEvents> {
        return this.emitter}
    public demo() {
        this.emitter.emit('tick', 1)
        this.emitter.emit('reset')
    }
}

class SampleEmitterClient {
    constructor (server:SampleEmitterServer) {
        const emitter = server.getEmitter()  // is 'this' defined here?
        emitter.on('tick', (t:number) => {console.log(t)})
        emitter.on('reset', () => {console.log('reset')})
    }

}




export interface IEmittingClock {

    /** resets the time to 0 */
    reset():void  

    /**
     * increments the time and sends a .nofify message with the 
     * current time to all the consumers
     */
    tick():void 
    
    /** adds another listener; returns the clock's emitter */
    addListener(): TypedEmitter<ClockEvents>
}

// no client interface necessary!
export class EmittingClock implements IEmittingClock {

    private time = 0

    private emitter = new EventEmitter as TypedEmitter<ClockEvents>

    reset(): void { this.time = 0; this.emitter.emit('reset') }

    tick(): void { this.time++; this.emitter.emit('tick', this.time) }

    public addListener(): TypedEmitter<ClockEvents> { return this.emitter }

}




export class EmittingClockClient {
    private time : number = 0 // time is undefined until the next tick
    constructor(theclock: IEmittingClock) {
        const clock: TypedEmitter<ClockEvents> = theclock.addListener()
        // set up event listeners       
        clock.on('tick', (t: number) => { this.time = t })
        clock.on('reset', () => { this.time = 0 })
    }

    getTime(): number { return this.time }
}

// the Observer gets to decide what to do with the notification

export class DifferentClockClient  {

    private time = 0  // time is not accurate until the next tick
    private notifications : number[] = [] // just for fun

    constructor (private theclock:IEmittingClock) {
        const clock : TypedEmitter<ClockEvents> = theclock.addListener()        
        clock.on('tick', (t:number) => {this.receiveTick(t)})
        clock.on('reset', () => {this.time = 0})
    }

    private receiveTick (t: number) : void { 
        this.notifications.push(t)
        this.time =  t * 2 }
    
    getTime () : number {return this.time / 2}
}






