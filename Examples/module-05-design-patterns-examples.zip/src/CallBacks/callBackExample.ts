export class Child {

    private _onClick: () => void

    constructor (onClick: () => void) {
        this._onClick = onClick
    }

    public click () { this._onClick() }
}
export class Parent {

    // the next free ID for a client
    private _nextID = 1

    // the log keeps track of the clicks by ID
    private _log: number[] = []

    public get log(): number[] { return this._log }
    private pushToLog(id: number) { this._log.push(id) }

    public newChild(): Child {
        const thisID = this._nextID
        // the 'function onClick().." syntax doesn't work here.
        const onClick = () => { this.pushToLog(thisID) }
        this._nextID++
        return new Child(onClick.bind(this)) 
    }
}




