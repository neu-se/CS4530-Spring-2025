import { Parent } from './callBackExample'

describe('handler passing', () => {

    it('works', () => {

        const server = new Parent()
        const client1 = server.newChild()
        const client2 = server.newChild()

        expect(server.log).toEqual([])
        client1.click()
        expect(server.log).toEqual([1])
        client2.click()
        expect(server.log).toEqual([1, 2])
        client1.click()
        expect(server.log).toEqual([1, 2, 1])
    })

})