import { SimpleClock } from '../PullingClocks/simpleClockUsingPull';
import IClock from "../PullingClocks/IPullingClock";

export class SimpleClockFactory {
    public static createClock () : IClock {
        return new SimpleClock()
    }
}