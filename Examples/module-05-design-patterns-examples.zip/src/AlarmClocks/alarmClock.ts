import { SimpleClock } from "../PullingClocks/simpleClockUsingPull"
import IPullingClock from "../PullingClocks/IPullingClock"

/** Another example of the callback pattern.
 * For the purposes of the pattern, AlarmClock is a client/child, and the controller is the server/parent
 * .
 * Each controller receieves ticks from an external source and forwards them to the clock or clocks
 * that it controls.
 * 
 * Three examples of different controllers are provided:
 * - LoggingController logs all ticks and alarms from two clocks.  
 * - SimpleLoggingController logs all ticks and alarms from a single clock.  It is a client of the clock.
 * - DistributingController distributes alarms from multiple clocks to a single upstream listener.
 *   The upstream listener is supplied to the controller at construction time.
*/

export class AlarmClock extends SimpleClock implements IPullingClock {

    // the condition for the alarm to go off
    // supplied in the constructor
    private _alarmCondition: ((arg0: number) => boolean)

    // the action to take when the alarm goes off
    // initially, do nothing
    private _onAlarm: () => void = () => { }

    public tick() {
        super.tick()
        if (this._alarmCondition(this.time)) {
            this._onAlarm()
        }
    }
    
    public set onAlarm(listener: () => void) {
        this._onAlarm = listener
    }

    // clock is constructed with a fixed alarm condition.
    // alarm action can be changed dynamiclly
    constructor(
        alarmCondition: (arg0: number) => boolean) {
        super()
        this._alarmCondition = alarmCondition
    }

}


export interface Tickable {
    tick(): void;
}


// need to export this type so that clients of the controller
// can use it in their type annotations
export type LogEntry = "tick" | "alarm1" | "alarm2";
/**
 * takes 2 alarm clocks.
 * Rece ives ticks from an external source and forwards them to both clocks.
 * Keeps a log of the ticks and any alarms that were triggered.
 */
export class LoggingController {
    private _alarmClock1: AlarmClock;
    private _alarmClock2: AlarmClock;

    private _log: LogEntry[] = [];

    public get log(): LogEntry[] {
        return this._log
    }

    // HERE ARE THE CALLBACKS FOR HANDLING ALARMS
    private handleAlarm1 () {
        this._log.push("alarm1")
    }

    private handleAlarm2 () {
        this._log.push("alarm2")
    }    

    public tick() {
        this._log.push("tick")  // log the tick before any alarms
        // tick both clocks.  Log alarm1 if it goes off, then alarm2.
        this._alarmClock1.tick()  
        this._alarmClock2.tick()     
        }

    constructor(
        alarmClock1: AlarmClock,
        alarmClock2: AlarmClock) {

        this._alarmClock1 = alarmClock1        
        this._alarmClock1.onAlarm = this.handleAlarm1.bind(this)

        this._alarmClock2 = alarmClock2
        this._alarmClock2.onAlarm = this.handleAlarm2.bind(this)
    }
}

type Listener = () => void
/**
 * a controller that tracks a single clock and logs its ticks and alarms
 */
export class SimpleLoggingController implements Tickable {

        private _alarmClock1: AlarmClock;
        
        private handleAlarm1 () {
            this._log.push("alarm1")
        }
            
        private _log: LogEntry[] = [];    
        public get log(): LogEntry[] { return this._log }
    
        // receive ticks from an external source and forwards them to the clock.
        public tick() {
            // log the tick before any alarms
            this._log.push("tick")             
            // send the tick to the clock.  Log alarm1 if it goes off.
            this._alarmClock1.tick()  
        }
    
        constructor(alarmClock:AlarmClock) { 
            this._alarmClock1 = alarmClock;
            this._alarmClock1.onAlarm = this.handleAlarm1.bind(this)
        } 

    }
       



/** a controller that listens for alarms from a list of clocks
 * and distributes them to its own upstream listener.
 */
export class DistributingController  {
    private _upstreamListener: Listener 
    private _clocks: AlarmClock[] = []
    
    public addClock(clock: AlarmClock) {
        this._clocks.push(clock);
        clock.onAlarm = this._upstreamListener
    }  

    public tick() {
        this._clocks.forEach(clock => clock.tick())
    }

    constructor(listener: Listener) {
        this._upstreamListener = listener
    }   
    
}




