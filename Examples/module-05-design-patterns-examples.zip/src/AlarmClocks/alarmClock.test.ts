import { LoggingController,AlarmClock, DistributingController, 
    Tickable,SimpleLoggingController } from "./alarmClock";


function divisibleby2(time: number): boolean {
    return time % 2 == 0
}

function divisibleBy5(time: number): boolean {
    return time % 5 == 0
}

function tickNTimes(controller:Tickable, n:number) {
    if (n == 0) return;
    controller.tick()
    tickNTimes(controller, n-1)
}
describe("LoggingController", () => {
    let controller: LoggingController;
    // start each test with fresh clocks and a fresh controller
    beforeEach(() => {
        const alarmClock2 = new AlarmClock(divisibleby2)
        const alarmClock5 = new AlarmClock(divisibleBy5)
        controller = new LoggingController(alarmClock2, alarmClock5)
    })

    it('tickNTimes 0 should leave an empty log', () => {
        tickNTimes(controller, 0)
        expect(controller.log).toEqual([])
    })

    it("should log a tick when a tick is received", () => {
        controller.tick()
        expect(controller.log).toEqual(["tick"])
    })

    it("should log an alarm1 after 2 ticks", () => {    
        controller.tick();
        controller.tick();
        expect(controller.log).toEqual(["tick", "tick", "alarm1"])
    })

    
    it('tickNTimes 2 should log two ticks and an alarm1', () => {
        tickNTimes(controller, 2)
        expect(controller.log).toEqual(["tick", "tick", "alarm1"])
    })

    it("after 5 ticks, should log an alarm2", () => {        
        tickNTimes(controller, 5)
        expect(controller.log).toEqual(
            ["tick", "tick", "alarm1",
                "tick", "tick", "alarm1",
                "tick", "alarm2"])
    })


    it('after 10 ticks, should trigger both alarms', () => {
        tickNTimes(controller, 10)
        expect(controller.log).toEqual(
            ["tick", "tick", "alarm1",   // after 2 ticks, alarm1 goes off
                "tick", "tick", "alarm1", // after 4 ticks, alarm1 goes off again
                "tick", "alarm2", // after 5 ticks, alarm2 goes off
                "tick", "alarm1", // after 6 ticks, alarm1 goes off again
                "tick", "tick", "alarm1", // after 8 ticks, alarm1 goes off again
                "tick", "tick", "alarm1", "alarm2"]) // after 10 ticks, both alarms go off
    }) 

})

describe("DistributingController", () => {
    let controller: DistributingController;
    let upstreamListener: jest.Mock
    // start each test with fresh clocks and a fresh controller
    beforeEach(() => {
        upstreamListener = jest.fn()
        const alarmClock2 = new AlarmClock(divisibleby2)
        const alarmClock5 = new AlarmClock(divisibleBy5)
        controller = new DistributingController(upstreamListener)
        controller.addClock(alarmClock2)
        controller.addClock(alarmClock5)
    })

    it('tickNTimes 0 should not call the upstream controller', () => {
        tickNTimes(controller, 0)
        expect(upstreamListener).not.toHaveBeenCalled()
    })

    it("single tick doesn't trigger the upstream listener", () => {
        controller.tick()
        expect(upstreamListener).not.toHaveBeenCalled()
    })

    it("should log an alarm1 after 2 ticks", () => {    
        controller.tick();
        controller.tick();        
        expect(upstreamListener).toHaveBeenCalledTimes(1)
    })

    
    it('tickNTimes 2 should log two ticks and an alarm1', () => {
        tickNTimes(controller, 2)
        expect(upstreamListener).toHaveBeenCalledTimes(1)
    })

    it("after 5 ticks, should log an alarm2", () => {        
        tickNTimes(controller, 5)
        expect(upstreamListener).toHaveBeenCalledTimes(3)   //2,4,5
    })

    it('after 10 ticks, should trigger both alarms', () => {
        tickNTimes(controller, 10)
        expect(upstreamListener).toHaveBeenCalledTimes(7)  //2,4,5,6,8,10,10  (2 alarms at 10)
    })

})


describe("SimpleLoggingController", () => {
    let controller: SimpleLoggingController;
    beforeEach(() => {
        const alarmClock2 = new AlarmClock(divisibleby2);
        controller = new SimpleLoggingController(alarmClock2);
    });

    it('tickNTimes 0 should leave an empty log', () => {
        tickNTimes(controller, 0);
        expect(controller.log).toEqual([]);
    });

    it("should log a tick when a tick is received", () => {
        controller.tick();
        expect(controller.log).toEqual(["tick"]);
    });

    it("should log an alarm1 after 2 ticks", () => {
        controller.tick();
        controller.tick();
        expect(controller.log).toEqual(["tick", "tick", "alarm1"]);
    });

    it('tickNTimes 2 should log two ticks and an alarm1', () => {
        tickNTimes(controller, 2);
        expect(controller.log).toEqual(["tick", "tick", "alarm1"]);
    });

    it("after 5 ticks, should alarm1 twice", () => {
        tickNTimes(controller, 5);
        expect(controller.log).toEqual(
            ["tick", "tick", "alarm1",
                "tick", "tick", "alarm1",
                "tick"]);
    });

    it('after 10 ticks, should trigger alarm1 every other tick', () => {
        tickNTimes(controller, 10);
        expect(controller.log).toEqual(
            ["tick", "tick", "alarm1",
                "tick", "tick", "alarm1",
                "tick", "tick", "alarm1",
                "tick", "tick", "alarm1",
                "tick", "tick", "alarm1" ]);
    });
});

describe("DistributingController", () => {
    let controller: DistributingController;
    let upstreamListener: jest.Mock;
    beforeEach(() => {
        upstreamListener = jest.fn();
        const alarmClock2 = new AlarmClock(divisibleby2);
        const alarmClock5 = new AlarmClock(divisibleBy5);
        controller = new DistributingController(upstreamListener);
        controller.addClock(alarmClock2);
        controller.addClock(alarmClock5);
    });

    it('tickNTimes 0 should not call the upstream controller', () => {
        tickNTimes(controller, 0);
        expect(upstreamListener).not.toHaveBeenCalled();
    });

    it("single tick doesn't trigger the upstream listener", () => {
        controller.tick();
        expect(upstreamListener).not.toHaveBeenCalled();
    });

    it("should log an alarm1 after 2 ticks", () => {
        controller.tick();
        controller.tick();
        expect(upstreamListener).toHaveBeenCalledTimes(1);
    });

    it('tickNTimes 2 should log two ticks and an alarm1', () => {
        tickNTimes(controller, 2);
        expect(upstreamListener).toHaveBeenCalledTimes(1);
    });

    it("after 5 ticks, should log an alarm2", () => {
        tickNTimes(controller, 5);
        expect(upstreamListener).toHaveBeenCalledTimes(3);
    });

    it('after 10 ticks, should trigger both alarms', () => {
        tickNTimes(controller, 10);
        expect(upstreamListener).toHaveBeenCalledTimes(7);
    });
});

describe("SimpleLoggingController", () => {
    let controller: SimpleLoggingController;
    beforeEach(() => {
        const alarmClock2 = new AlarmClock(divisibleby2);
        controller = new SimpleLoggingController(alarmClock2);
    });

    it('tickNTimes 0 should leave an empty log', () => {
        tickNTimes(controller, 0);
        expect(controller.log).toEqual([]);
    });

    it("should log a tick when a tick is received", () => {
        controller.tick();
        expect(controller.log).toEqual(["tick"]);
    });

    it("should log an alarm1 after 2 ticks", () => {
        controller.tick();
        controller.tick();
        expect(controller.log).toEqual(["tick", "tick", "alarm1"]);
    });

    it('tickNTimes 2 should log two ticks and an alarm1', () => {
        tickNTimes(controller, 2);
        expect(controller.log).toEqual(["tick", "tick", "alarm1"]);
    });

    it("after 4 ticks, should log two alarm1", () => {
        tickNTimes(controller, 4);
        expect(controller.log).toEqual(["tick", "tick", "alarm1", 
            "tick", "tick", "alarm1"]);
    });

    it('after 10 ticks, should trigger five alarm1', () => {
        tickNTimes(controller, 10);
        expect(controller.log).toEqual(
            ["tick", "tick", "alarm1",
                "tick", "tick", "alarm1",
                "tick", "tick", "alarm1",
                "tick", "tick", "alarm1",
                "tick", "tick", "alarm1"]);
    });
});
