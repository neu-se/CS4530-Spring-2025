

export interface IPushingClock {

    /** resets the time to 0 */
    reset():void  

    /**
     * increments the time and sends a .nofify message with the 
     * current time to all the consumers
     */
    tick():void 
    
    /** adds another clienta */
    addListener(listener:IPushingClockClient):number 
}

interface IPushingClockClient {
    /**
     *  * @param t - the current time, as reported by the clock
     */
    notify(t:number):void
}

export class PushingClock implements IPushingClock {
    private time = 0

    reset() : void { this.time = 0; this.notifyAll() }
 
    tick() : void { this.time++; this.notifyAll() }     
    
    private observers: IPushingClockClient[] = []

    public addListener(obs:IPushingClockClient): number {
        this.observers.push(obs);
        return this.time
    }

    private notifyAll() : void {
            this.observers.forEach(obs => obs.notify(this.time))
        }
}

export class PushingClockClient implements IPushingClockClient {

    private time:number
    constructor (theclock:IPushingClock) {
        this.time = theclock.addListener(this)
    }

    notify (t:number) : void {this.time = t}

    clientTime () : number {return this.time}
}

// the Observer gets to decide what to do with the notification
export class DifferentClockClient implements IPushingClockClient {
    
    /** TWICE the current time, as reported by the clock */
    private twiceTime:number

    constructor (theclock:IPushingClock) {
        this.twiceTime = theclock.addListener(this) * 2
    }

    /** list of all the notifications received */
    public readonly notifications : number[] = [] // just for fun

    notify(t: number) : void { 
        this.notifications.push(t)
        this.twiceTime =  t * 2 }

    getTime() : number { return (this.twiceTime / 2) }
}





