/** Simple example, with useEffect, for fetching from a web site */

import * as React from 'react';
import { useState,useEffect} from 'react';
import {
  Box,
  Button,
  Heading, HStack,
  VStack, IconButton,
} from '@chakra-ui/react';
import axios from 'axios';

export default function HttpRequestWithUseEffect() {
    const [data, setData] = useState('waiting...')
    const [waiting, setWaiting] = useState(false)  // have we already tried to fetch data?
    const [postNumber, setPostNumber] = useState(1) // which post are we fetching?

    async function fetchData(n) {
      if (waiting) return;
      setWaiting(true);
      setData("waiting...");
      try {
        const response = await axios.get(
          `https://jsonplaceholder.typicode.com/posts/${n}`
        );
        setWaiting(false);
        setData(response.data.title);
      } catch (error) {
        setData("Error fetching data");
        setWaiting(false);
        return;
      }
    }

    // load the first piece of data on startup
    // empty array means only do this once, on startup
    useEffect(() => {fetchData(1)}, [])       

    function fetchMoreData() {
        const n = Math.floor(Math.random() * 100) + 1
        setPostNumber(n)
        fetchData(n)
    }     

    return (
        <VStack>
            <h1><b>Fetching from a web site:</b></h1>
            <Box>Post #{postNumber} is: {data}</Box>
            <Button onClick={fetchMoreData}>Fetch Again</Button>

        </VStack>
    )
}