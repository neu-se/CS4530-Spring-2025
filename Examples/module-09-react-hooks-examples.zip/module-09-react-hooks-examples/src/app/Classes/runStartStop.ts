import { Clock } from "./ClockWithStartStop";

function main() {
    const clock = new Clock(1000);
    clock.addListener(() => {console.log("Tick")});
    clock.start();
    // after 5 seconds, stop the clock
    setTimeout(() => {clock.stop()}, 5000);
}

main();