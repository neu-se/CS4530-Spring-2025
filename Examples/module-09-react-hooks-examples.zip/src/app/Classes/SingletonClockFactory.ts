/* eslint-disable max-classes-per-file */

import IClock from './PullingClocks/IPullingClock'
import { SimpleClock } from './PullingClocks/simpleClockUsingPull'

// class Clock1 implements IClock {
//     // implementation of IClock
//     private time = 0

//     public reset () : void {this.time = 0}

//     public tick () : void { this.time++ }

//     public getTime(): number { return this.time }
// }

export default class SingletonClockFactory  {

    private static theClock : IClock | undefined 

    private constructor () {SingletonClockFactory.theClock = undefined}
    
    public static instance () : IClock {
        if (SingletonClockFactory.theClock === undefined) {
            SingletonClockFactory.theClock  = new SimpleClock()
        }
        return SingletonClockFactory.theClock
    }
}
